# References

- Microsoft IoT for Beginners GitHub repository: https://github.com/microsoft/IoT-For-Beginners
- Lesson 7 assignment: Build a more efficient watering cycle
- Lesson 8 assignment: Learn about cloud services
- Lesson 9 assignment: Add manual relay control
- Lesson 10 assignment: Build a new IoT device
- Lesson 11 assignment: Investigate other GPS data
- Lesson 12 assignment: Investigate function bindings
- Lesson 13 assignment: Deploy your app
- Lesson 14 assignment: Send notifications using Twilio

Note: This submission explains the assignment requirements and adds original sample code for learning purposes. It does not copy personal endpoints, account data, connection strings, or private credentials.
