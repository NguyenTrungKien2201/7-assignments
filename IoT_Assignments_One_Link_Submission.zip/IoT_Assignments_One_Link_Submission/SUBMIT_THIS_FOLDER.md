# Submission Instructions

Submit this entire folder as one link, using either GitHub or Google Drive.

## Folder to submit

`IoT_Assignments_One_Link_Submission`

## What is included

This folder contains the completed IoT assignment materials for lessons 7 to 14:

1. Lesson 07: Automated Plant Watering
2. Lesson 08: Cloud Services
3. Lesson 09: Manual Relay Control
4. Lesson 10: New IoT Device
5. Lesson 11: GPS Extra Data
6. Lesson 12: Blob Output Binding
7. Lesson 13: Static Web App
8. Lesson 14: Twilio Geofence Notifications

Each lesson folder includes an `ANSWER.md` file. Some lessons also include source code, configuration files, or sample data.

## Option 1: Submit using Google Drive

1. Extract the ZIP file.
2. Upload the entire folder `IoT_Assignments_One_Link_Submission` to Google Drive.
3. Right-click the uploaded folder.
4. Select **Share**.
5. Change access to **Anyone with the link can view**.
6. Copy the folder link.
7. Submit that single link to the teacher.

## Option 2: Submit using GitHub

1. Create a new public or private GitHub repository.
2. Upload all files and folders from `IoT_Assignments_One_Link_Submission`.
3. Make sure the repository contains all lesson folders and the README files.
4. Copy the repository URL.
5. Submit that single link to the teacher.

## Notes

- Do not submit each assignment as a separate link.
- Do not submit only individual files.
- Submit the whole folder or repository link.
- If the teacher requires exactly 7 assignments, confirm which lesson should be excluded because lessons 7 through 14 include 8 lessons in total.
