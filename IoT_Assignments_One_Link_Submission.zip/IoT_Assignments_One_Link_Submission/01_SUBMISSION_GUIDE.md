# Submission guide

Submit the complete folder `IoT_Lessons_7_14_Submission_EN` or the ZIP file with the same name.

The package includes:

- Detailed written answers for each lesson in `ANSWER.md`.
- Sample source code for lessons that require implementation.
- Sample configuration files for Azure Functions, Azure Blob output binding, Azure Static Web Apps, and Twilio binding.
- No real secret, connection string, phone number, or subscription key.

If the teacher requires a real demonstration, the following resources must be added by the student:

1. Azure subscription.
2. Azure IoT Hub.
3. Device ID and device connection string.
4. Registry Manager connection string with service permissions.
5. Azure Storage account.
6. Azure Maps key.
7. Twilio account and verified phone number.

All places that require replacement are written as environment variables or placeholders such as `<your key>`, `<device id>`, or `<service policy connection string>`.
