# IoT for Beginners Submission: Lessons 7 to 14

## General information

- Course: Microsoft IoT for Beginners
- Submission scope: Lessons 7, 8, 9, 10, 11, 12, 13, and 14
- Implementation format: virtual IoT devices, Python sample code, Azure Functions examples, Azure Blob Storage output binding, Azure Static Web Apps sample, Azure Maps configuration pattern, and Twilio SMS notification logic.
- Security note: no real secret, connection string, phone number, or subscription key is included. All sensitive values are represented as environment variables or placeholders.

## Lesson list

| Lesson | Topic | Folder |
|---:|---|---|
| 07 | Automated plant watering | `lesson_07_automated_plant_watering` |
| 08 | Migrate your plant to the cloud | `lesson_08_cloud_services` |
| 09 | Migrate application logic to the cloud, manual relay control | `lesson_09_manual_relay_control` |
| 10 | Keep your plant secure and design a new IoT device | `lesson_10_new_iot_device` |
| 11 | Location tracking and extended GPS data | `lesson_11_gps_extra_data` |
| 12 | Store location data with an Azure Functions output binding | `lesson_12_blob_output_binding` |
| 13 | Visualize location data and deploy a web app | `lesson_13_static_web_app` |
| 14 | Geofences and Twilio notifications | `lesson_14_twilio_geofence_notifications` |

## Folder structure

Each lesson folder contains:

1. `ANSWER.md`: the written answer, explanation, analysis, and run instructions.
2. `code/` or `function_app/`: sample source code for lessons that require implementation.
3. Configuration examples that use placeholders instead of real credentials.

## General run instructions

For Python-based lessons, use the following pattern:

```bash
python -m venv .venv
source .venv/bin/activate       # macOS/Linux
# .venv\Scripts\activate       # Windows
pip install -r requirements.txt
```

For Azure Functions lessons, use:

```bash
func start
```

Before running Azure Functions with real Azure services, create a local `local.settings.json` file on your own computer or configure the equivalent Application Settings in Azure. Do not submit files that contain real connection strings or keys.

## Common environment variables

| Variable | Purpose |
|---|---|
| `IOTHUB_DEVICE_CONNECTION_STRING` | Allows an IoT device to connect to Azure IoT Hub |
| `REGISTRY_MANAGER_CONNECTION_STRING` | Allows Azure Functions to invoke direct methods on devices |
| `DEVICE_ID` | Target IoT device identifier |
| `AZURE_MAPS_KEY` | Azure Maps subscription key |
| `TwilioAccountSid` | Twilio account SID |
| `TwilioAuthToken` | Twilio authentication token |
| `TwilioFromNumber` | Twilio sender phone number |
| `AlertToNumber` | Recipient phone number for alerts |
